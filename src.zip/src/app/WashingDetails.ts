export class WashingDetails{
    washtype:String;
    washpackage:String;
    scheduledate:String;
    constructor(washtype:String,washpackage:String,scheduledate:String){}
}