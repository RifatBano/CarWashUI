export class PhotoDetails{

    title:String;
    image:File;

    constructor(title:String,image:File){};
    
}