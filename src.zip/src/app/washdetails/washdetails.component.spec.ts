import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WashdetailsComponent } from './washdetails.component';

describe('WashdetailsComponent', () => {
  let component: WashdetailsComponent;
  let fixture: ComponentFixture<WashdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WashdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WashdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
