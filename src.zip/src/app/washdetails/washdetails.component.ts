import { Component, OnInit } from '@angular/core';
import {WashingDetails} from '../WashingDetails';
import {LoginService} from '../login.service';
import {Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-washdetails',
  templateUrl: './washdetails.component.html',
  styleUrls: ['./washdetails.component.css']
})
export class WashdetailsComponent implements OnInit {

  washDetails: WashingDetails= new WashingDetails("","","");
  message: any;
  public errorMsg;
  errorcontrol: boolean=false;
  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }

  public addwashDetails(){
    this.service.addWashdetails(this.washDetails).subscribe(
      data =>{
        this.message=data;
        console.log("entered washdetails");
        this.router.navigate(['/addphoto']);
      },
      error =>{
        this.errorMsg = error.error.message;
        this.errorcontrol = true;
      }
    )
  }


}
