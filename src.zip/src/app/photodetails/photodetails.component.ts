import { Component, OnInit } from '@angular/core';
import {PhotoDetails} from '../PhotoDetails';
import {LoginService} from '../login.service';
import {Router} from '@angular/router';
import { from } from 'rxjs';

@Component({
  selector: 'app-photodetails',
  templateUrl: './photodetails.component.html',
  styleUrls: ['./photodetails.component.css']
})
export class PhotodetailsComponent implements OnInit {

  photoDetails: PhotoDetails= new PhotoDetails("",null);
  message: any;
  public errorMsg;
  errorcontrol: boolean=false;
  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }

  public submit(){
    this.service.addphotodetails(this.photoDetails).subscribe(
      data =>{
        this.message=data;
        console.log("entered photodetails");
        this.router.navigate(['/success']);
      },
      error =>{
        this.errorMsg = error.error.message;
        this.errorcontrol = true;
      }
    )
  }

}
