import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhotodetailsComponent } from './photodetails.component';

describe('PhotodetailsComponent', () => {
  let component: PhotodetailsComponent;
  let fixture: ComponentFixture<PhotodetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhotodetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhotodetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
