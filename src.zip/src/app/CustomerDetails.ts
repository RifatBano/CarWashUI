export class CustomerDetails{

    name:String;
    password:String;
    constructor(name:String,password : String ){}
}