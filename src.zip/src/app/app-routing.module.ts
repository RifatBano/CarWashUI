import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {RegisterComponent} from './register/register.component';
import {CardetailsComponent} from './cardetails/cardetails.component';
import {AddressdetailsComponent} from './addressdetails/addressdetails.component';
import {WashdetailsComponent} from './washdetails/washdetails.component';
import {PhotodetailsComponent} from './photodetails/photodetails.component';
const routes: Routes = [
  {
    path: '',redirectTo: 'login',pathMatch: 'full'},
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'cardetails', component: CardetailsComponent},
  { path: 'addressdetails', component: AddressdetailsComponent},
  { path: 'washdetails', component: WashdetailsComponent},
  { path: 'addphoto', component: PhotodetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
