import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import {Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  public register(custDetails) {
    return this.http.post("http://localhost:8081/customer/register", custDetails, { responseType: 'text' as 'json' });
  }

  public login(custDetails): Observable<any> {
    return this.http.post("http://localhost:8081/customer/login", custDetails, { responseType: 'text' as 'json' });
  }

  public addcardetails(carDetails): Observable<any> {
    return this.http.post("http://localhost:8081/customer/cardetails", carDetails, { responseType: 'text' as 'json' });
  }

  public addAddressdetails(addressDetails): Observable<any> {
    return this.http.post("http://localhost:8081/customer/details", addressDetails, { responseType: 'text' as 'json' });
  }
  
  public addWashdetails(washDetails): Observable<any> {
    return this.http.post("http://localhost:8081/customer/details", washDetails, { responseType: 'text' as 'json' });
  }

  public addphotodetails(photoDetails): Observable<any> {
    return this.http.post("http://localhost:8081/customer/details", photoDetails, { responseType: 'text' as 'json' });
  }
}
