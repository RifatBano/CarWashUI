import { Component, OnInit } from '@angular/core';
import {CustomerDetails} from '../CustomerDetails';
import {LoginService} from '../login.service';
import {Router} from '@angular/router';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  custDetails: CustomerDetails= new CustomerDetails("","");
  message: any;
  public errorMsg;
  errorcontrol: boolean=false;
  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }

  public submit(){
    this.service.register(this.custDetails).subscribe(
      data =>{
        this.message=data;
        this.router.navigate(['/login']);
      },
      error =>{
        this.errorMsg = error.error.message;
        this.errorcontrol = true;
      }
    )
  }

}
