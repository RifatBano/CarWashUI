export class AddressDetails{

    state:String;
    city:String;
    locality:String;
    blocknumber:String;
    pin:String;
    phoneno:String;
    constructor(state:String,city:String,locality:String,blocknumber:String,pin:String,phoneno:String){}
}