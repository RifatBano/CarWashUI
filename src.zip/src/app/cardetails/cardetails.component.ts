import { Component, OnInit } from '@angular/core';
import {CarDetails} from '../CarDetails';
import {LoginService} from '../login.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-cardetails',
  templateUrl: './cardetails.component.html',
  styleUrls: ['./cardetails.component.css']
})
export class CardetailsComponent implements OnInit {

  carDetails: CarDetails= new CarDetails("","");
  message: any;
  errorMsg: any;
  errorcontrol: boolean=false;

  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }

  public addCarDetails(){
    this.service.addcardetails(this.carDetails).subscribe(
      data =>{
        this.message=data;
        console.log("hello from cardetails");
        this.router.navigate(['/addressdetails']);
      },
      error =>{
        this.errorMsg = this.service;
        this.errorcontrol = true;
      }
    )
  }
}
