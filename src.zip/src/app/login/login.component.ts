import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {LoginService} from '../login.service';
import {CustomerDetails} from '../CustomerDetails';
import { HttpErrorResponse } from '@angular/common/http';
import { from } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  custDetails: CustomerDetails= new CustomerDetails("","");
  message: any;
  errorMsg: any;
  errorcontrol: boolean=false;

  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }

  public login(){
    this.service.login(this.custDetails).subscribe(
      data =>{
        this.message=data;
        console.log("hello from login");
        this.router.navigate(['/cardetails']);
      },
      error =>{
        this.errorMsg = this.service;
        this.errorcontrol = true;
      }
    )
  }

}
