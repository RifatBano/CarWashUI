export class CarDetails{

    carmodel:String;
    nameplateno:String;
    constructor(carmodel:String,nameplateno:String ){}
}