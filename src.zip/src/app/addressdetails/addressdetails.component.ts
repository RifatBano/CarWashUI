import { Component, OnInit } from '@angular/core';
import {AddressDetails} from '../AddressDetails';
import {LoginService} from '../login.service';
import {Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-addressdetails',
  templateUrl: './addressdetails.component.html',
  styleUrls: ['./addressdetails.component.css']
})
export class AddressdetailsComponent implements OnInit {

  addressDetails: AddressDetails= new AddressDetails("","","","","","");
  message: any;
  errorMsg: any;
  errorcontrol: boolean=false;

  constructor(private service:LoginService, public router:Router) { }

  ngOnInit(): void {
  }
  public addDetails(){
    this.service.addAddressdetails(this.addressDetails).subscribe(
      data =>{
        this.message=data;
        console.log("hello from addressdetails");
        this.router.navigate(['/washdetails']);
      },
      error =>{
        this.errorMsg = this.service;
        this.errorcontrol = true;
      }
    )
  }

}
